public class Pyramid extends GeometricShape3D {
    private float baseArea;
    private float height;
    
    public Pyramid(float baseArea, float height) {
        this.baseArea = baseArea;
        this.height = height;
    }
    
    @Override
    public float calculateVolume() {
        return (baseArea * height) / 3;
    }
    
    @Override
    public float calculateArea() {
        return baseArea + (float) (Math.sqrt(Math.pow(baseArea / 2, 2) + Math.pow(height, 2)));
    }
    
    @Override
    public void printInfo() {
        System.out.println("Pyramid: " + baseArea + ", " + height + "(Volume = " + calculateVolume() + ")");
    }

    public float setBaseArea(float baseArea) {
        return this.baseArea = baseArea;
    }

    public float setHeight(float height) {
        return this.height = height;
    }
    
}
