public class Rectangle extends GeometricShape2D {
    private float width;
    private float height;
    
    public Rectangle(float width, float height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public float calculateArea() {
        return width * height;
    }

    @Override
    public void printInfo() {
        System.out.println("Rectangle: " + width + " by " + height + "(Area = " + calculateArea() + ")");
    }
    
    public float getWidth() {
        return width;
    }
    
    public float getHeight() {
        return height;
    }
    
    public void setWidth(float width) {
        this.width = width;
    }
    
    public void setHeight(float height) {
        this.height = height;
    }
}
