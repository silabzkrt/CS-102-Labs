public class Circle extends Ellipse {
    public Circle(float radius) {
        super(radius, radius);
    }

    @Override
    public void printInfo() {
        System.out.println("Circle: " + getSemiMajorAxis() + "(Area = " + calculateArea() + ")");
    }

    @Override
    public float calculateArea() {
        return (float) (Math.PI * getRadius() * getRadius());
    }

    public float getRadius() {
        return getSemiMajorAxis();
    }

    public void setRadius(float radius) {
        setSemiMajorAxis(radius);
        setSemiMinorAxis(radius);
    }

    
}
