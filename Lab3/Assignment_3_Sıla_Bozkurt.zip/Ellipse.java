public class Ellipse extends GeometricShape2D {
    private float semiMajorAxis;
    private float semiMinorAxis;
    
    public Ellipse(float semiMajorAxis, float semiMinorAxis) {
        this.semiMajorAxis = semiMajorAxis;
        this.semiMinorAxis = semiMinorAxis;
    }

    @Override
    public float calculateArea() {
        return (float) (Math.PI * semiMajorAxis * semiMinorAxis);
    }

    @Override
    public void printInfo() {
        System.out.println("Ellipse: " + semiMajorAxis + " by " + semiMinorAxis + "(Area = " + calculateArea() + ")");
    }
    
    public float getSemiMajorAxis() {
        return semiMajorAxis;
    }
    
    public float getSemiMinorAxis() {
        return semiMinorAxis;
    }
    
    public void setSemiMajorAxis(float semiMajorAxis) {
        this.semiMajorAxis = semiMajorAxis;
    }
    
    public void setSemiMinorAxis(float semiMinorAxis) {
        this.semiMinorAxis = semiMinorAxis;
    }
    
}
