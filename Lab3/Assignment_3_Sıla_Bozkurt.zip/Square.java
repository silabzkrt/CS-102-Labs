public class Square extends Rectangle {
    public Square(float side) {
        super(side, side);
    }
    
    @Override
    public void printInfo() {
        System.out.println("Square: " + "edge length" + this.getSide() + "(Area = " + calculateArea() + ")");
    }
    
    public float getSide() {
        return getWidth();
    }
    
    public void setSide(float side) {
        setWidth(side);
        setHeight(side);
    }
    
    public static void main(String[] args) {
        Square square = new Square(5);
        square.printInfo();
        square.setSide(10);
        square.printInfo();
    }
    
    
}
