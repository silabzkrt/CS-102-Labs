package labs102.Lab1;

public class GameMain {
    Game game = new Game();
    game.initializeGame();
}
