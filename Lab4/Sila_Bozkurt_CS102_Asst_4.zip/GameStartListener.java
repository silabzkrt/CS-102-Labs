public interface GameStartListener {
    void onGameStart(Game game);
}
